
enum AppFeedbackType {
  success,
  error,
  info,
  warning,
}
